# au prealable, vous devez executer l'instruction suivante
#install.packages('randtoolbox')

library(randtoolbox)
source("generateurs.R")
source("tests.R")

graine <- runif(1, 3000, 4000);
Nsimu <- 100
Nrepet <- 100

vn <- VonNeumann(Nsimu, Nrepet, graine)
mt <- MersenneTwister(Nsimu,Nrepet,graine)
RANDU <- RANDU(Nsimu, Nrepet, graine)
sm <- StandardMinimal(Nsimu, Nrepet, graine)

Histo(vn, mt, randu, sm)
Plot(vn, mt, randu, sm)


frequency_vn = rep(0, Nrepet)
frequency_mt = rep(0, Nrepet)
frequency_randu = rep(0, Nrepet)
frequency_sm = rep(0, Nrepet)

run_vn = rep(0, Nrepet)
run_mt = rep(0, Nrepet)
run_randu = rep(0, Nrepet)
run_sm = rep(0, Nrepet)

ordre_vn = rep(0, Nrepet)
ordre_mt = rep(0, Nrepet)
ordre_randu = rep(0, Nrepet)
ordre_sm = rep(0, Nrepet)

for (i in 1:Nrepet)
{
  frequency_vn[i] <- Frequency(vn[,i], 14)
  frequency_mt[i] <- Frequency(mt[,i], 32)
  frequency_randu[i] <- Frequency(RANDU[,i], 31)
  frequency_sm[i] <- Frequency(sm[,i], 31)
  
  run_vn[i] <- Runs(vn[,i], 14)
  run_mt[i] <- Runs(mt[,i], 32)
  run_randu[i] <- Runs(RANDU[,i], 31)
  run_sm[i] <- Runs(sm[,i], 31)
  
  ordre_vn[i] <- Ordre(vn[,i])
  ordre_mt[i] <- Ordre(mt[,i])
  ordre_randu[i] <- Ordre(RANDU[,i])
  ordre_sm[i] <- Ordre(sm[,i])
}

# Test Fréquence monobit
# Von Neumann
(mean(frequency_vn))
# Mersenne Twister
(mean(frequency_mt))
# RANDU
(mean(frequency_randu))
# Standard Minimal
(mean(frequency_sm))

# Test Runs
# Von Neumann
(mean(run_vn))
# Mersenne Twister
(mean(run_mt))
# RANDU
(mean(run_randu))
# Standard Minimal
(mean(run_sm))

# Test Ordre
# Von Neumann
(mean(ordre_vn))
# Mersenne Twister
(mean(ordre_mt))
# RANDU
(mean(ordre_randu))
# Standard Minimal
(mean(ordre_sm))